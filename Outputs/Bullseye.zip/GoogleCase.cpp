#include "StdAfx.h"
#include "GoogleCase.h"

GoogleCase::GoogleCase()//)QObject* parent /*= 0*/)
// 	: QObject(parent)
{

}

GoogleCase::~GoogleCase()
{

}
