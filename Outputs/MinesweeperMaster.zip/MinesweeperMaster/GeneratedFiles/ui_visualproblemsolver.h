/********************************************************************************
** Form generated from reading UI file 'visualproblemsolver.ui'
**
** Created by: Qt User Interface Compiler version 5.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VISUALPROBLEMSOLVER_H
#define UI_VISUALPROBLEMSOLVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MinesweeperMasterClass
{
public:
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_5;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *pEditDrop;
    QPushButton *pUseSampleButton;
    QHBoxLayout *horizontalLayout;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_2;
    QPlainTextEdit *pEditSampleInput;
    QGroupBox *pGroupSamplOut;
    QVBoxLayout *verticalLayout_4;
    QPlainTextEdit *pEditSampleOutput;
    QCheckBox *pPassedCheckBox;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_3;
    QPlainTextEdit *pEditComputedOutput;
    QDoubleSpinBox *pTimeBox;
    QPushButton *pFailedButton;
    QProgressBar *pProgressBar;

    void setupUi(QWidget *MinesweeperMasterClass)
    {
        if (MinesweeperMasterClass->objectName().isEmpty())
            MinesweeperMasterClass->setObjectName(QStringLiteral("MinesweeperMasterClass"));
        MinesweeperMasterClass->resize(824, 522);
        MinesweeperMasterClass->setAcceptDrops(true);
        verticalLayout_6 = new QVBoxLayout(MinesweeperMasterClass);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        groupBox = new QGroupBox(MinesweeperMasterClass);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setSpacing(2);
        verticalLayout->setContentsMargins(2, 2, 2, 2);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        pEditDrop = new QPlainTextEdit(groupBox);
        pEditDrop->setObjectName(QStringLiteral("pEditDrop"));
        pEditDrop->setAcceptDrops(false);

        verticalLayout->addWidget(pEditDrop);


        verticalLayout_5->addWidget(groupBox);

        pUseSampleButton = new QPushButton(MinesweeperMasterClass);
        pUseSampleButton->setObjectName(QStringLiteral("pUseSampleButton"));
        pUseSampleButton->setMinimumSize(QSize(0, 50));

        verticalLayout_5->addWidget(pUseSampleButton);


        horizontalLayout_2->addLayout(verticalLayout_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        groupBox_2 = new QGroupBox(MinesweeperMasterClass);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        verticalLayout_2 = new QVBoxLayout(groupBox_2);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        pEditSampleInput = new QPlainTextEdit(groupBox_2);
        pEditSampleInput->setObjectName(QStringLiteral("pEditSampleInput"));
        pEditSampleInput->setAcceptDrops(false);

        verticalLayout_2->addWidget(pEditSampleInput);


        horizontalLayout->addWidget(groupBox_2);

        pGroupSamplOut = new QGroupBox(MinesweeperMasterClass);
        pGroupSamplOut->setObjectName(QStringLiteral("pGroupSamplOut"));
        verticalLayout_4 = new QVBoxLayout(pGroupSamplOut);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        pEditSampleOutput = new QPlainTextEdit(pGroupSamplOut);
        pEditSampleOutput->setObjectName(QStringLiteral("pEditSampleOutput"));
        pEditSampleOutput->setAcceptDrops(false);

        verticalLayout_4->addWidget(pEditSampleOutput);

        pPassedCheckBox = new QCheckBox(pGroupSamplOut);
        pPassedCheckBox->setObjectName(QStringLiteral("pPassedCheckBox"));
        pPassedCheckBox->setIconSize(QSize(28, 28));
        pPassedCheckBox->setCheckable(true);

        verticalLayout_4->addWidget(pPassedCheckBox);


        horizontalLayout->addWidget(pGroupSamplOut);

        groupBox_3 = new QGroupBox(MinesweeperMasterClass);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        verticalLayout_3 = new QVBoxLayout(groupBox_3);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        pEditComputedOutput = new QPlainTextEdit(groupBox_3);
        pEditComputedOutput->setObjectName(QStringLiteral("pEditComputedOutput"));
        pEditComputedOutput->setAcceptDrops(false);

        verticalLayout_3->addWidget(pEditComputedOutput);

        pTimeBox = new QDoubleSpinBox(groupBox_3);
        pTimeBox->setObjectName(QStringLiteral("pTimeBox"));
        pTimeBox->setButtonSymbols(QAbstractSpinBox::NoButtons);
        pTimeBox->setDecimals(3);
        pTimeBox->setMaximum(1000);

        verticalLayout_3->addWidget(pTimeBox);

        pFailedButton = new QPushButton(groupBox_3);
        pFailedButton->setObjectName(QStringLiteral("pFailedButton"));
        pFailedButton->setEnabled(true);
        pFailedButton->setMinimumSize(QSize(0, 50));
        QFont font;
        font.setPointSize(28);
        pFailedButton->setFont(font);

        verticalLayout_3->addWidget(pFailedButton);


        horizontalLayout->addWidget(groupBox_3);


        horizontalLayout_2->addLayout(horizontalLayout);


        verticalLayout_6->addLayout(horizontalLayout_2);

        pProgressBar = new QProgressBar(MinesweeperMasterClass);
        pProgressBar->setObjectName(QStringLiteral("pProgressBar"));
        pProgressBar->setValue(5);
        pProgressBar->setTextVisible(true);
        pProgressBar->setInvertedAppearance(false);
        pProgressBar->setTextDirection(QProgressBar::TopToBottom);

        verticalLayout_6->addWidget(pProgressBar);


        retranslateUi(MinesweeperMasterClass);

        QMetaObject::connectSlotsByName(MinesweeperMasterClass);
    } // setupUi

    void retranslateUi(QWidget *MinesweeperMasterClass)
    {
        MinesweeperMasterClass->setWindowTitle(QApplication::translate("MinesweeperMasterClass", "MinesweeperMaster", 0));
        groupBox->setTitle(QApplication::translate("MinesweeperMasterClass", "Sample and file drop", 0));
        pEditDrop->setPlainText(QApplication::translate("MinesweeperMasterClass", "\n"
"\n"
"\n"
"Drag and drop the input file here", 0));
        pUseSampleButton->setText(QApplication::translate("MinesweeperMasterClass", "Use Sample", 0));
        groupBox_2->setTitle(QApplication::translate("MinesweeperMasterClass", "Resulting Sample Input", 0));
        pGroupSamplOut->setTitle(QApplication::translate("MinesweeperMasterClass", "Resulting Sample Output", 0));
        pPassedCheckBox->setText(QApplication::translate("MinesweeperMasterClass", "Passed", 0));
        groupBox_3->setTitle(QApplication::translate("MinesweeperMasterClass", "Computed Output", 0));
        pTimeBox->setPrefix(QString());
        pTimeBox->setSuffix(QApplication::translate("MinesweeperMasterClass", " s", 0));
        pFailedButton->setText(QApplication::translate("MinesweeperMasterClass", "FAILED !", 0));
        pProgressBar->setFormat(QApplication::translate("MinesweeperMasterClass", "%v", 0));
    } // retranslateUi

};

namespace Ui {
    class MinesweeperMasterClass: public Ui_MinesweeperMasterClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VISUALPROBLEMSOLVER_H
